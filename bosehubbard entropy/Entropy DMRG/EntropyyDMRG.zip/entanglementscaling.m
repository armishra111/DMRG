N = 10; L = 10; mu = 0; t = 0.2; U = 1; V = 0; k = 0; conserved_QNum = NaN;
%model = BoseHubbardChain(L, N, U, mu, t, V, k, BoundCond.periodic, conserved_QNum);
%BoseHubbard_DMRG = DMRG(model);
%dmrg_input.m_warmup = 20;
%[Energy, gnd_state] = BoseHubbard_DMRG.iDMRG(dmrg_input);

%M = BoseHubbard_DMRG.reduce_densityM;  

%S = real(-trace(M*logm(M))); 

y = [];
z = []; 
for ccount=1:20
    t=ccount/10
for count=1:12
   model = BoseHubbardChain(L, N, U, mu, t, V, k, BoundCond.periodic, conserved_QNum);
   BoseHubbard_DMRG = DMRG(model);
   dmrg_input.m_warmup = 5*count;
   [Energy1, gnd_state] = BoseHubbard_DMRG.iDMRG(dmrg_input); 
   M = BoseHubbard_DMRG.reduce_densityM;  
   S = real(-trace(M*logm(M)));
   z(end+1) = S;
   y(end+1) = dmrg_input.m_warmup;
end
end 