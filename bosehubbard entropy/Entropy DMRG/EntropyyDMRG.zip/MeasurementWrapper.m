classdef MeasurementWrapper < handle
    properties
        measurement = OuterObject.empty
    end
    
    methods
        function self = MeasurementWrapper()
        end
    end
end

