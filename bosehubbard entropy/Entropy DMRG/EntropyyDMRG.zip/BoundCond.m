classdef BoundCond
    enumeration
       open, periodic
    end
end

